ArbiSense — Sessione 2025-10-26 22:41:04
- Fix segno PnL verificato (SHORT: exit_z < entry_z → PnL positivo).
- WF: FOLDS=3, TOTAL_PNL_FIXED≈+2953 su SWDA short-only → preset pronto.
- backtest_signals.py sostituito (PnL corretto, date tz-aware).
- Domani: fix interpretazione colonna (bps vs percent).
Comandi ultimi usati: walk-forward prudente + backtest singola coppia.
